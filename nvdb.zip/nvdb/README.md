# NVDBPlugin
NVDB Read and Write: QGIS It's a Plugin for NVDB (Norwegian Road Database) to analyse and modified objects road and submited back to NVDB.

![README](https://github.com/JACCCostring/NVDBPlugin/assets/93591202/c444632b-c8e9-4add-8634-86a01a1cbc6b)

![image](https://github.com/JACCCostring/NVDBPlugin/assets/93591202/a634b683-34ca-4c80-a5f2-6cfbeeb112a9)

![image](https://github.com/JACCCostring/NVDBPlugin/assets/93591202/2466741b-6642-44e4-a01b-a6f0b79b6fa1)

![image](https://github.com/JACCCostring/NVDBPlugin/assets/93591202/cc256852-dead-4b15-b248-48fcb9e64c7b)
