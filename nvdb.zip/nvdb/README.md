NVDB Les og Skriv
NVDB Les og Skriv Plug-In for å håndtere data fra NVDB (Nasjonal Veg Databank), å få mulighet for å lesing, visualiserer, redigerer og sent data tilbake allerede redigert til NVDB, cool :).


<b>For å begyne, klone Plug-In repo</b>
```git
git clone https://git.vegvesen.no/scm/nvdbdov/nvdb-qgis-plugin.git
```


<b>Vi har Test Integrasjon i plug-in og det make sure at alle komponenter i Plug-In er i god form og test gjør neste: </b>
<ol>
<li>Check hvis kan Laste ned Datakatalog Data</li>
<li>Check hvis kan Laste ned Egenskaper Data</li>
<li>Check hvis kan Laste ned Vegobjekter Data</li>
<li>Check hvis Bruker kan Logge seg inn</li>
<li>Check hvis Bruker kan send Egenskaper, Sammekoblinger og Stedfesting Endringssetter<li>
</ol>


<b>kjører test for å se at alt gå bra med koden</b>
```python
python/python3 -m pytest -v
```

Hvis all test er passed, da bra :)

Andre ting er at det må ligger en .env fil for handle secrets når bruker må logge seg inn før kjører test fil.


Bruker lage en fil med neste verdier:
```python
localenv_svv_pass='svv_pass_her' #må følge base64 data format for eccryption. https://www.base64encode.org/
username='username'
```
Og lagre fil med ingen navn men .env fil ekstension.


Plug-In er laget ved å bruker NVDB Dokumentasjon: <href>https://nvdb.atlas.vegvesen.no/docs/category/nvdb-api-les</href>

også vi bruker REST API endpoints for data source og Datakatalogen for å bli kjent med data schema av alle vegobjekttyper i NVDB.

Datakatalogen: <href>https://datakatalogen.test.atlas.vegvesen.no/</href>


<b>For Videre Utviklings, kun Intern:</b>

<href>https://www.vegvesen.no/wiki/display/NBD/QGIS+-+Hvordan+utvikler+vi+programtilleggene+i+TeamNVDB</href>

<b>Husk å installere dependencies før kjøre test og videre utviklings</b>
```git
pip/pip3 install -r requirements.txt
```

<b>of course du også trenger QGIS, Qt og Python:</b>
<ol>
<li>QGIS Versjon: 3.34.3 or greater</li>
<li>Qt Versjon: 5.15.3 or greater</li>
<li>Python Versjon: 3.9.18 or greater</li>
</ol>


<h1>Show Cases</h1>

![image](https://github.com/JACCCostring/NVDBPlugin/assets/93591202/a634b683-34ca-4c80-a5f2-6cfbeeb112a9)

![image](https://github.com/JACCCostring/NVDBPlugin/assets/93591202/cc256852-dead-4b15-b248-48fcb9e64c7b)
