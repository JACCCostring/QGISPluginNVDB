from qgis.PyQt import uic
from qgis.utils import iface
from qgis.core import QgsProject

from PyQt5.QtWidgets import QTableWidgetItem, QMessageBox
from PyQt5.QtCore import pyqtSignal
import os

#user defined modules
from .nvdbLesWrapper import AreaGeoDataParser
from .vegrefStedfestning import VegrefStedfestning
from .more_window_status import Ui_MoreWindowStatus

FORM_CLASS, BASE_CLASS = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'more_window.ui'))

class SourceMoreWindow(BASE_CLASS, FORM_CLASS):
    
    new_relation_event = pyqtSignal(int, str) #signal for sending selected items
    
    unlink_btn_clicked = pyqtSignal() #signal for when unlink btn clicked
    
    logging_btn_moreWindow_clicked = pyqtSignal() #signal when user clicked open window btn
    
    maintab_index_change = pyqtSignal(int) #signal triger when tab change
    
    pick_up_loggin = pyqtSignal() #to deliver login data back and forward
    
    on_new_geo_data = pyqtSignal(dict) #when new geometry available from nvdb_beta_dialog
    
    new_geometry_rcv = pyqtSignal(dict)

    on_fetch_button_clicked = pyqtSignal()
    
    _including_child = pyqtSignal(bool) #when turning including barn checkbox
    
    on_endringsett_correct_active = pyqtSignal(bool)
    on_endringsett_update_active = pyqtSignal(bool)

    def __init__(self):
        super().__init__()
        
        self.setupUi(self)
        
        #tab widget control flags
        self.location_tab_active:bool = False
        self.relation_tab_active:bool = False
        self.is_user_logged: bool = False
        # self.is_line_position_ready: bool = False
        
        # self.times_checking_vegref_validation: int = int()
        
        #for controlling env, default is test
        self.current_env: str = 'test' #for environment if test or prod, etc default = test
        self.token: str = str() #for token when posting stadfestning, etc
        self.stedfest_type: str = str() #for knowing what type of object was selected in QGIS kart
        self.current_nvdb_object_type: int = int() #for storing nvdb object type from nvdb_beta_dialog module
        # self.position_list: list = [str] #for adding positions when stadfesting line or polygon types
        # self.line_from_to_positions: dict = {} #for adding line from and to positions when ready
        # self.list_of_endringssett: list = [] #to have control with sent endringssett
        self.status_window = None #for status window for stadfesting and sammenkoblingen
        
        #end of tab widget control flags
        
        #setting default tab index flag according to current index
        self.setup_default_tab_index_flags()
        
        #setting default values to table relation show
        self.setup_default_table_relation()
        
        #and notifying to self.more_main_tab widget of the change
        self.more_main_tab.currentChanged.emit(1) # 1 relasjoner tab
        
        #setting some default to UI components
        self.unlink_from_parent_btn.setEnabled(False)
        self.object_id_line.setReadOnly(True)
        self.login_btn_more_window.setEnabled(False)
        self.relocate_vegref_btn.setEnabled(False)
        self.vegref_line_input.setEnabled(False)
        self.fra_vegref_input.setEnabled(False)
        self.til_vegref_input.setEnabled(False)
        self.relocate_line_btn.setEnabled(False)
        self.relation_correct_changeset_btn.toggle()
        
        #making a global scope vegrefStedfestning class instance
        self.vegref_instance = VegrefStedfestning()
        
        #end of setting default index flag
        
        self.more_main_tab.currentChanged.connect(self.activate_current_tab) #when current tab changes
        self.table_relation_show.clicked.connect(self.item_clicked) #when any item is clicked in table
        self.unlink_from_parent_btn.clicked.connect(self.onUnlink_btn_clicked) #when unlink btn is clicked
        
        #self.unlink_from_parent_btn.clicked.connect(self.display_msg) #comment here (can be call inside self.onUnlink_btn_clicked() method as well
        
        self.login_btn_more_window.clicked.connect(self.onLoggingClicked) #an easy access to login tab from skrivWindow
        
        self.vegref_line_input.returnPressed.connect(self.handle_validation_vegref) #validate when key enter is pressed
        self.vegref_line_input.textChanged.connect(self.handle_validation_vegref) #everytime line edit changes
        
        self.relocate_vegref_btn.clicked.connect(self.sentGeoDataForStedfestning) #when stedfesting punkt
        self.relocate_line_btn.clicked.connect(self.sentGeoDataForStedfestning) #when stedfesting linje
        
        self.fra_vegref_input.textChanged.connect(self.handle_validation_vegref) #when from input lineEdit changes
        self.til_vegref_input.textChanged.connect(self.handle_validation_vegref) #when to input lineEDit changes
        
        self.new_geometry_rcv.connect(self.on_new_geometry) #when signal is emited then execute
        
        self.status_btn.clicked.connect(self.open_status_window) #when opening window

        self.fetch_data_btn.clicked.connect(self.onFetchClicked) #When fetching new data

        self.include_child_check.stateChanged.connect(self.on_including_child) #wether including child or not

        #when user toggle one of the radio btn for endringssett types
        self.relation_correct_changeset_btn.toggled.connect(self.endringssett_type_correct_changed)
        self.relation_update_changeset_btn.toggled.connect(self.endringssett_type_update_changed)
        
        
    def activate_current_tab(self, index):
        
        # print('changing to', index)
        
        if self.more_main_tab.currentIndex() == 0:
            self.location_tab_active = True
            self.relation_tab_active = False

        else:
            self.relation_tab_active = True
            self.location_tab_active = False
        
        #notifying that current tab has changed to nvdb_beta_dialog modulen
        self.maintab_index_change.emit(index)
        

    def action_(self):
        if self.location_tab_active:
            self.relocate_vegobjekter()

        elif self.relation_tab_active:
            self.make_relationship_vegobjekter()

    def relocate_vegobjekter(self):
        # stedfesting code here ...
        pass

    def make_relationship_vegobjekter(self):
        # sammenkobling code here ...
        pass

    def set_realtion_child_id(self, current_object, current_object_type):
        
        self.object_id_line.setText(f"{current_object_type} - {str(current_object)}")
        self.object_id_line_stedfest.setText(f"{current_object_type} - {str(current_object)}")

    def set_current_vref(self, vref):
        self.segments_list.clear()
        if len(vref) == 1:
            self.vegref_lbl.setText(vref[0])
            self.segments_list.clear()
        else:
            for item in vref:
                if item != self.vegref_lbl.text():
                    self.segments_list.addItem(item)


    def feed_data(self, component_type: str = str(), data: dict = {}, active_parent: str = str()):
        if component_type == 'relation':
           #relasjon code here ...
            AreaGeoDataParser.set_env(self.get_current_env()) #setting environment before use
            
            #getting possible parents
            possible_relation = AreaGeoDataParser.get_possible_parents(int(data.get('objekttype')))
            
            #populating relation component with possible parents
            self.populate_relation_component(possible_relation)

        if component_type == 'location':
            #stedfest code here ...
            self.current_nvdb_object_type = data.get('nvdb_object_type') #data['nvdb_object_type']
            self.stedfest_type = data.get('stedfest_type') #data['stedfest_type']
            
            # print(data)
            
            #enabling UI elements when something is clicked from nvdb_beta_dialog module
            if data.get('stedfest_type') == 'punkt':
        
                self.vegref_line_input.setEnabled(True)
                
                #deactivating line inputs if activated
                if self.fra_vegref_input.isEnabled() or self.til_vegref_input.isEnabled():
                    
                    self.fra_vegref_input.clear()
                    self.til_vegref_input.clear()
                    
                    self.fra_vegref_input.setEnabled(False)
                    self.til_vegref_input.setEnabled(False)
                    
                    # self.vegref_check_label.clear()
                    self.line_vegref_check_label.clear()
                    
                    self.relocate_line_btn.setEnabled(False)
            
            if data.get('stedfest_type') == 'linje' or data.get('stedfest_type') == 'flate' or data.get('stedfest_type') == 'hjelpelinje':
                
                # print('enabling linje UI')
                
                self.fra_vegref_input.setEnabled(True)
                self.til_vegref_input.setEnabled(True)
                
                #deactivating punkt inputs if activated
                if self.vegref_line_input.isEnabled():
                    
                    self.vegref_line_input.clear()
                    
                    self.vegref_line_input.setEnabled(False)
                    
                    # self.line_vegref_check_label.clear()
                    self.vegref_check_label.clear()
                    
                    self.relocate_vegref_btn.setEnabled(False)
            
            # if 'flate' in data['stedfest_type']:
                
            #     print('enabling flate UI')
                
            #     self.fra_vegref_input.setEnabled(True)
            #     self.til_vegref_input.setEnabled(True)
                
            #     #deactivating punkt inputs if activated
            #     if self.vegref_line_input.isEnabled():
                    
            #         self.vegref_line_input.clear()
                    
            #         self.vegref_line_input.setEnabled(False)
        
        if component_type == 'location' and data.get('is_new_geometry') == True:
            
            self.stedfest_type = data.get('stedfest_type')
            
            #GETTING GEOMETRY AS WKT FORMAT STR
            geo = data.get('new_geometry').asWkt()
            
            attribs = {
               'object_type': data.get('nvdb_object_type'),
               'nvdbid': self.get_especific_field_by_name('nvdbid'),
               'stedfest_type': data.get('stedfest_type'),
               'startdato': self.get_especific_field_by_name('sistmodifisert'),
               'new_geo': geo.replace('LineStringZ', 'LineString Z')
            }
            
            # print(attribs)
            
            self.new_geometry_rcv.emit(attribs)
        
        if component_type == 'status':
            
            '''but self.token it maight allready exist, because it's call in handle_ref_validarion method
            when login first time'''
            self.check_loging()
            
            #if window allready exist then just feed
            if self.status_window:
                
                self.status_window.feed_changeset( {'target': data['target'], 'type': data['type'], 'token': self.token} )
            
            #if not then create it, hide it and feed it
            if not self.status_window:
                
                self.open_status_window()
                
                self.status_window.hide()
                
                self.status_window.feed_changeset( {'target': data['target'], 'type': data['type'], 'token': self.token} )
    
    def get_current_env(self):
        return self.current_env
    
    def set_current_env(self, current_env: str = str()):
        curr: str = str()
        
        if 'test' in current_env:
            curr = 'test'
        
        if 'prod' in current_env:
            curr = 'prod'
            
        self.current_env = curr
        
        print('chaning env in more window', self.get_current_env())
        
    def set_parent_status(self, status_info: dict = {}):
        if not status_info:
            
            self.current_linked_parent_lbl.clear()
            
            self.avvist_lbl.setText("Ikke koblet til mor!")
            self.avvist_lbl.setStyleSheet("color: grey; font: 14pt 'MS Shell Dlg 2';")
            
        if status_info:
            
            self.current_linked_parent_lbl.setText(f"Koblinger - {status_info['parent_id']} - {status_info['parent_name']} - {status_info['parent_nvdbid']}")

    def populate_relation_component(self, data: dict = {}):
        row: int = 0

        self.table_relation_show.setRowCount(len(data))

        for item in data:
            name_item = QTableWidgetItem(item['name'])
            id_item = QTableWidgetItem(str(item['id']))

            self.table_relation_show.setItem(row, 0, id_item)
            self.table_relation_show.setItem(row, 1, name_item)

            row += 1

    def item_clicked(self, item):
        id = int(self.table_relation_show.item(item.row(), 0).text())
        name = self.table_relation_show.item(item.row(), 1).text()
        
        self.new_relation_event.emit(id, name)

    def onUnlink_btn_clicked(self):
        self.unlink_btn_clicked.emit()
        
    # internal own class methods for inside uses
    def setup_default_tab_index_flags(self):
        if self.more_main_tab.currentIndex() == 0:  # 0 stedfesting tab
            self.location_tab_active = True
            self.relation_tab_active = False
            
            print('stedfest tab')

        elif self.more_main_tab.currentIndex() == 1:  # 1 kobling tab
            self.relation_tab_active = True
            self.location_tab_active = False
            
            print('relasjon tab')

        else:
            self.relation_tab_active = True
            self.location_tab_active = False

            
    def setup_default_table_relation(self):
        label_headers = ['Objekttype', 'Navn']
        
        self.table_relation_show.setColumnCount(2)
        self.table_relation_show.setHorizontalHeaderLabels(label_headers)

    def display_msg(self):
        msg = QMessageBox()
        msg.setWindowTitle("Status")
        msg.setText("Operasjon sendt!")
        msg.exec()

    def set_status(self, status):
        
        pass
        
        self.avvist_lbl.clear()

    def set_msg_avvist(self, msg):
        
        self.avvist_lbl.setStyleSheet(f"color: red; font: 10pt 'MS Shell Dlg 2';")
        self.avvist_lbl.setText(msg)

    def set_login_status(self, status):
        if status == "pålogget":
            self.status_innlogging_lbl.setText("Pålogget")
            self.status_innlogging_lbl.setStyleSheet("color: green; font: 14pt 'MS Shell Dlg 2';")
            self.login_btn_more_window.setEnabled(False)
            
        else:
            self.status_innlogging_lbl.setText('må logge på')
            self.status_innlogging_lbl.setStyleSheet("color: red; font: 14pt 'MS Shell Dlg 2';")
            self.login_btn_more_window.setEnabled(True)

    def turn_remove_relation_btn(self, dependant_mor, has_parent: bool = False, status_login: bool = False, extra: dict = {}) -> bool:
        
        self.avvist_lbl.clear()

        if not dependant_mor and has_parent and status_login:
            
            exist_child_inParent = AreaGeoDataParser.check_if_child_exist_in_parent( extra.get('parent_nvdb_type'), extra.get('parent_nvdbid'), extra.get('child_to_compare') )
            
            # print( 'flag exist child in parent:', exist_child_inParent )
            # print( extra )
            
            self.unlink_from_parent_btn.setEnabled(True)
            
            # self.avvist_lbl.setStyleSheet("color: magenta; font: 14pt 'MS Shell Dlg 2';")
            
            '''
            making sure that child do not exist in parent tree relationship, because sometimes
            NVDB Les still showing childre's old parent relationship even if those are not present
            in it's tree's relationship.
            '''
            
            if exist_child_inParent:
                
                # self.avvist_lbl.setText("Vegobjekt har allereder mor, for å lagge til ny mor må slett nåværende!")
            
                self.table_relation_show.setEnabled(True) #False
                
                return True
            
            if not exist_child_inParent:
                
                self.avvist_lbl.setStyleSheet("color: #FEBE10; font: 14pt 'MS Shell Dlg 2';")
                
                self.avvist_lbl.setText("Vegobjektet viser fortsatt den gamle forelderen, selv om det ikke lenger har en forelder!")
                
                self.table_relation_show.setEnabled(True)
                
                self.unlink_from_parent_btn.setEnabled(False)
                
                return False

        else:
            
            self.unlink_from_parent_btn.setEnabled(False)
            
            self.table_relation_show.setEnabled( True )
            
            if dependant_mor:
                
                self.avvist_lbl.setText("må ha forelder, kan ikke fjernes men kan erstattes!")
                
                self.avvist_lbl.setStyleSheet("color: grey; font: 14pt 'MS Shell Dlg 2';")
                
                return True
                
            elif not has_parent:
                
                self.avvist_lbl.setText("Ikke koblet til mor!")
                
                self.avvist_lbl.setStyleSheet("color: grey; font: 14pt 'MS Shell Dlg 2';")
                
                self.table_relation_show.setEnabled(True)

    def onLoggingClicked(self):
        self.logging_btn_moreWindow_clicked.emit()

    def onFetchClicked(self):
        self.on_fetch_button_clicked.emit()
    
    def get_especific_field_by_name(self, field_name)-> str:
        layer = iface.activeLayer()

        especific_field = {}
        nvdbid = None
        
        try:
            
            for feature in layer.selectedFeatures():
                for field in feature.fields():
                    if field_name in field.name():
                        return feature[field.name()]
        
        except AttributeError as ex:
            
            print( ex )


    def handle_validation_vegref(self):
        attribs: dict = {}
        check_vegnet: bool = False
            
        '''
        checking if vegref is valid, throug some method calling
        in VegrefStedfestning class
        '''
            
        #if user is logged, then can continue
        self.check_loging()
            
        #setting attribs instance already exist in __init__() method
        self.vegref_instance.set_attributes({'token': self.token})
        
        self.vegref_instance.set_env('prod')
        
        #extra
        extra_ = {
                'start_date': self.get_especific_field_by_name('sistmodifisert'),
                'trafikant_gruppe': self.get_especific_field_by_name('trafikantgruppe'),
                'nvdbid': self.get_especific_field_by_name('nvdbid'),
                'type': self.current_nvdb_object_type,
                'versjon': self.get_especific_field_by_name('versjon')
        }

        #if user is logged
        if self.is_user_logged:
                
            #PUNKT case
            if 'punkt' in self.stedfest_type:
                    
                if self.vegref_instance.check_vegref(self.vegref_line_input.text().replace('-', '').lstrip().rstrip()):
                    
                    self.redraw_stedfest_ui(self.stedfest_type, True)
                        
                    attribs = {
                        'stedfest_type': self.stedfest_type,
                        'fra': self.vegref_line_input.text().replace('-', '').lstrip().rstrip()
                    }

                    #print(attribs)

                    self.vegref_instance.get_position(attribs)
                    
                    #stedfestning road object
                    self.vegref_instance.stedfest_object( extra_ )
                
                else:
                    
                    self.redraw_stedfest_ui(self.stedfest_type, False)
        
            #LINJE case
            if 'linje' or 'flate' or 'hjelpelinje' in self.stedfest_type:
                        
                if self.vegref_instance.check_vegref(self.fra_vegref_input.text().replace('-', '').lstrip().rstrip()) and self.vegref_instance.check_vegref(self.til_vegref_input.text().replace('-', '').lstrip().rstrip()):
                    
                    self.redraw_stedfest_ui(self.stedfest_type, True)
                    
                    attribs = {
                        'stedfest_type': self.stedfest_type,
                        'fra': self.fra_vegref_input.text().replace('-', '').lstrip().rstrip(),
                        'til': self.til_vegref_input.text().replace('-', '').lstrip().rstrip()
                    }
                    
                    check_vegnet = self.vegref_instance.get_position(attribs)
                    
                    #stedfestning road object
                    if 'linje' or 'hjelpelinje' in self.stedfest_type:
                        
                        self.vegref_instance.stedfest_object( extra_ )
                
                        # self.vegref_instance.stedfest_object( extra_, True, self.get_geometry_by_nvdbid_fromQGIS(extra_.get('nvdbid') ))
                    
                    if 'flate' in self.stedfest_type:
                        
                        self.redraw_stedfest_ui('linje', True)
                        
                        self.vegref_instance.stedfest_object( extra_, True, self.get_geometry_by_nvdbid_fromQGIS(extra_.get('nvdbid') ))
                    
                    if not check_vegnet:
                        
                        self.check_vegnet_field.setStyleSheet("color: pink; font: 14pt 'MS Shell Dlg 2';")
                        self.check_vegnet_field.setText('Vegreferanse overlapp, en gyldig vegreferanse må benyttes!: Ex: Punkt: EV134 S0D0 m377 Linje: EV134 S0D0 m377-455')
                    
                    if check_vegnet and self.check_vegnet_field.toPlainText() != ' ':
                        
                        self.check_vegnet_field.clear()
                        
                        self.check_vegnet_field.setStyleSheet("background-color: rgb(0, 0, 0, 0);") #black transparent
                else:
                    
                    if 'flate' in self.stedfest_type:
                        
                        self.redraw_stedfest_ui('linje', False) #we re-draw line not matter what, since same UI Elements are being used for flate here
                        
                    if 'linje' in self.stedfest_type:
                        
                        self.redraw_stedfest_ui(self.stedfest_type, False)
                    
                    if 'hjelpelinje' in self.stedfest_type:
                        
                        self.redraw_stedfest_ui('linje', False)
    
    
    def redraw_stedfest_ui(self, stedfest_type: str = str(), active: bool = False) -> None:
        #redraw stedfest ui according to stedfest type and if fail or not
        if 'punkt' in stedfest_type and active:
            
            self.vegref_check_label.setText("valid")
            self.vegref_check_label.setStyleSheet("color: green;")
                    
            # enabling stedfest btn if not valid
            if not self.relocate_vegref_btn.isEnabled():
                
                self.relocate_vegref_btn.setEnabled(True)
            
        if 'punkt' in stedfest_type and not active:
            
            self.vegref_check_label.setText("invalid")
            self.vegref_check_label.setStyleSheet("color: red;")
                    
            #dissabling stedfest linje btn if not valid
            if self.relocate_vegref_btn.isEnabled():
                
                self.relocate_vegref_btn.setEnabled(False)
        
        if 'linje' in stedfest_type and active:
            
            self.line_vegref_check_label.setText("valid")
            self.line_vegref_check_label.setStyleSheet("color: green;")
                    
            #enabling stedfest btn if not valid
            if not self.relocate_line_btn.isEnabled():
                self.relocate_line_btn.setEnabled(True)
            
        if 'linje' in stedfest_type and not active:
            
            self.line_vegref_check_label.setText("invalid")
            self.line_vegref_check_label.setStyleSheet("color: red;")
                    
            #dissabling stedfest linje btn if valid
            if self.relocate_line_btn.isEnabled():
                
                self.relocate_line_btn.setEnabled(False)
                
            
    def check_loging(self):
        '''
        emiting signal to pick up login in main window nvdb_beta_dialog.py modulen,
        if user has already logged in from Skriv_vinduet or sammenkobling tab
        '''
        self.pick_up_loggin.emit()
        
    def set_login_fromNVDBBetaDialog(self, v: bool = False, t: str = str()) -> None:
        self.is_user_logged = v
        self.token = t
        
    def sentGeoDataForStedfestning(self):
        if self.is_user_logged:
            
            try:
                
                data_to_send = {
                    'location': self.vegref_instance.egenskaper_stedfest,
                    'position': self.vegref_instance.geo_parsed
                }
            
                self.on_new_geo_data.emit( data_to_send )
                
            except AttributeError:
                print('source_more_window::sentGeoDataForStedfestning: exception = egenskaper_stedfest do not exist')
    
    def get_geometry_by_nvdbid_fromQGIS(self, nvdbid: int = int()) -> str:

        layer = iface.activeLayer()

        selected_object_fields = {}

        self.current_nvdbid = nvdbid
        
        geometry_found: str = str()

        try:
            
            for feature in layer.selectedFeatures():
        
                for field in feature.fields():
                    
                    if 'nvdbid' in field.name():
                        
                        if str(nvdbid) in str(feature[field.name()]):
                            
                            for feat_field in feature.fields():
                                # print(feat_field.name(), ': ', feature[feat_field.name()])

                                if 'Geometri' in feat_field.name():
                                    
                                    geometry_found = feature.geometry().asWkt()

                                    if 'PointZ' in geometry_found:
                                        
                                        geometry_found = geometry_found.replace('Point', 'Point Z')
                    
                                    if 'LineStringZ' in geometry_found:
                                        
                                        geometry_found = geometry_found.replace('LineStringZ', 'LineString Z')

                                    if 'PolygonZ' in geometry_found:
                                        
                                        geometry_found = geometry_found.replace('PolygonZ', 'Polygon Z')
                                        
        except AttributeError as ex:
                
            print( ex )
                
        return geometry_found
    
    def on_new_geometry(self, data: dict = {})-> None:
        
        geometry = self.get_geometry_by_nvdbid_fromQGIS(data.get('nvdbid'))
        
        attribs = {
            'type': data.get('object_type'),
            'nvdbid': data.get('nvdbid'),
            'startdato': data.get('startdato'),
            'geometry': geometry, #data.get('new_geo'),
            'stedfest_type': data.get('stedfest_type'),
            'env': self.get_current_env() if 'test' in self.get_current_env() else ''
        }
        
        #since it is an static method acces, we dont need access to self.instance
        v = VegrefStedfestning.get_vegref_from_wkt(attribs)
    
        print('source_more_window::on_new_geometry:', v)
        
        # print( 'geometry from QGIS:', geometry )
        # print('geometry from signal:', data.get('new_geo'))
        
        #case when is Punkt
        if attribs.get('stedfest_type') == 'punkt':
            
            self.vegref_line_input.setText(v.get('from'))
            
        #case when is Linje or Flate
        if attribs.get('stedfest_type') == 'linje' or attribs.get('stedfest_type') == 'hjelpelinje' or attribs.get('stedfest_type') == 'flate':
    
            self.fra_vegref_input.setText(self.get_vegref_min_max(min_=True, vegref_fra=v.get('from'), vegref_til=v.get('to')))
            self.til_vegref_input.setText(self.get_vegref_min_max(max_=True, vegref_fra=v.get('from'), vegref_til=v.get('to')))
    
    def open_status_window(self):
        
        #opening window
        
        #create new instance if not exist already
        if not self.status_window:
            
            self.status_window = Ui_MoreWindowStatus()
            
            self.status_window.show()
        
        #only show instance if it already exists
        if self.status_window:
            
            self.status_window.show()
    
    def on_including_child(self, state):
        
        s = True if state > 0 else False
        
        self._including_child.emit(s)
    
    def endringssett_type_correct_changed(self, toggle):
        
        self.on_endringsett_correct_active.emit(toggle)
    
    def endringssett_type_update_changed(self, toggle):
        
        self.on_endringsett_update_active.emit(toggle)
    
    def get_vegref_min_max(self, vegref_fra: str = str(), vegref_til: str = str(), min_: bool = False, max_: bool = False):
            
        # vegref_fra = self.fra_vegref_input.text().replace('-', '').lstrip().rstrip()
        # vegref_til = self.til_vegref_input.text().replace('-', '').lstrip().rstrip()
        min_str: str = str()
        max_str: str = str()
        
        meters_fra = vegref_fra.replace('-', '').lstrip().rstrip().split('m')
        meters_til = vegref_til.replace('-', '').lstrip().rstrip().split('m')
        
        #sub mfunction to check digits in vegref
        def contain_numbers(str_vegref):
            return any( ch.isdigit() for ch in str_vegref )
            
        # print('fra:', meters_fra)
        # print('til:', meters_til)
        
        if min_:
            
            '''
            making sure that vegref does not has number digits, 
            otherwise ew need to parse again
            '''
            if contain_numbers( meters_fra[1] ):
                
                min_str = meters_fra[1].split(' ')[0]
                
                min_str = str( max(int(min_str), int(meters_til[1].split(' ')[0])) )
                
                if min_str in vegref_fra:
                
                    return vegref_fra
                
            #normal case when the parsed does not contain numbers
            min_str = str( min(int(meters_fra[1]), int(meters_til[1])) )
                
            if min_str in vegref_fra:
                
                return vegref_fra
            
            return vegref_til
            
        if max_:
            
            '''
            making sure that vegref does not has number digits, 
            otherwise ew need to parse again
            '''
            if contain_numbers( meters_til[1] ):
                
                max_str = meters_til[1].split(' ')[0]
                
                max_str = str( max(int(meters_fra[1].split(' ')[0]), int(max_str)) )
                
                if max_str in vegref_til:
                
                    return vegref_til
                
            #normal case
            max_str = str( max(int(meters_fra[1]), int(meters_til[1])) )
            
            if max_str in vegref_til:
                
                return vegref_til
            
            return vegref_fra